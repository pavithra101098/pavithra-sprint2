package com.capg.im.service;

import java.util.Date;
import java.util.List;

//import com.capg.bank.entity.BankBean;
import com.capg.im.entity.RawMaterialBean;

public interface ITrackOrderService {
	
	//public RawMaterialBean trackOrder(String OrderId) ;
	//public boolean RawMaterialOrderIdExists(String Id);
	public RawMaterialBean insertRawMaterials(RawMaterialBean bean);
	public RawMaterialBean getRawMaterials(int id);
	public List<RawMaterialBean> getAll();
	//public  RawMaterialBean setDate(int id, Date processingdate);
	//public RawMaterialBean getmanufacturingDates(int id,Date manufacturingDate);
	//public RawMaterialBean getprocessingDate(int id,Date processingDate);
	 public RawMaterialBean deleteRawMaterials(int id);
	
	//public ProductDetails ProductOrder(String ProductId) throws ProductOrderNotFoundException;
}

