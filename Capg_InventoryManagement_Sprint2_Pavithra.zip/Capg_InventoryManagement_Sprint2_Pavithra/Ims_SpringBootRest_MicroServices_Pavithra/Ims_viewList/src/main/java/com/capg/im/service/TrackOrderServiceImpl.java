package com.capg.im.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.dao.IBankDao;
//import com.capg.bank.entity.BankBean;
import com.capg.im.dao.ITrackOrderDao;
import com.capg.im.entity.RawMaterialBean;

@Service
public class TrackOrderServiceImpl implements ITrackOrderService{
	@Autowired
	ITrackOrderDao dao;
	@Override
	public List<RawMaterialBean> getAll() {
		// TODO Auto-generated method stub
		return dao.getAll();
	}
}