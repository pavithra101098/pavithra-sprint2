package com.capg.im.controller;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
import com.capg.im.entity.RawMaterialBean;
//import com.capg.bank.service.BankServiceImpl;
import com.capg.im.service.TrackOrderServiceImpl;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class TrackOrderRestController {
	@Autowired
	TrackOrderServiceImpl tsi;
	@GetMapping("/rawmaterial/findall")   //GET:    http://localhost:8090/bank/findall    
	public List<RawMaterialBean> getall() {

		List<RawMaterialBean> bean = tsi.getAll();
		return bean;
	}}