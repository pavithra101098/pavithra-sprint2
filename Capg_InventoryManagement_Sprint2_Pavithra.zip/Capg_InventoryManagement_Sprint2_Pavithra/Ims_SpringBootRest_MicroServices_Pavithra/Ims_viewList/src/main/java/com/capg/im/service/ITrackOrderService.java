package com.capg.im.service;

import java.util.Date;
import java.util.List;

//import com.capg.bank.entity.BankBean;
import com.capg.im.entity.RawMaterialBean;

public interface ITrackOrderService {
	public List<RawMaterialBean> getAll();
}