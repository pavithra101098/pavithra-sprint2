package com.capg.im.dao;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.History;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.History;
//import com.capg.bank.entity.BankBean;
import com.capg.im.entity.RawMaterialBean;
@Repository
@Transactional
public class TrackOrderDaoImpl implements ITrackOrderDao{
	@PersistenceContext
	EntityManager em;
	@Override
	public List<RawMaterialBean> getAll() {
		TypedQuery<RawMaterialBean> query = em.createQuery("from RawMaterialBean", RawMaterialBean.class);
		return query.getResultList();
	}
}