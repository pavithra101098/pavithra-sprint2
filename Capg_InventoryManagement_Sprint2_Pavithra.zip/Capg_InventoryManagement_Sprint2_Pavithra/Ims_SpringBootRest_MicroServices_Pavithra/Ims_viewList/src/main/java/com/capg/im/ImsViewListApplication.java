package com.capg.im;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImsViewListApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImsViewListApplication.class, args);
	}

}
