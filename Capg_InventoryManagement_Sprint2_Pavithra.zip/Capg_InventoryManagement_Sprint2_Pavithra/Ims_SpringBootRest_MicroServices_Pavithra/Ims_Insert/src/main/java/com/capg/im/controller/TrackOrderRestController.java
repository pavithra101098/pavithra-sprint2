package com.capg.im.controller;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
import com.capg.im.entity.RawMaterialBean;
//import com.capg.bank.service.BankServiceImpl;
import com.capg.im.service.TrackOrderServiceImpl;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class TrackOrderRestController {
	@Autowired
	TrackOrderServiceImpl tsi;
	@PostMapping("/raw/insert")
	/**
	 * @author pavithra : This insertRawMaterials method will insert details into
	 *         the entity of rawmaterialbean
	 **/
	public String insertRawMaterials(@RequestBody RawMaterialBean bean) {
		RawMaterialBean rawmaterialbean = tsi.insertRawMaterials(bean);
		return "Hello " + rawmaterialbean.getName() + rawmaterialbean.getPricePerUnit()
				+ rawmaterialbean.getQuantityUnit() + "\n Your Insertion is Successfull\n" + "Your Account Id is "
				+ rawmaterialbean.getOrderId();
	}}