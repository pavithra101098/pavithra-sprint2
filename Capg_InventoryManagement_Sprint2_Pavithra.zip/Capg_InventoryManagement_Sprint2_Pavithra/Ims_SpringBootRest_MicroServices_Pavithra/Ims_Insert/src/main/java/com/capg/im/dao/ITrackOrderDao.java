package com.capg.im.dao;

import java.util.Date;
import java.util.List;

//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
import com.capg.im.entity.RawMaterialBean;

public interface ITrackOrderDao {
	
	public RawMaterialBean insertRawMaterials(RawMaterialBean bean);
}