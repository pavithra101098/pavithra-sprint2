package com.capg.im.service;

import java.util.Date;
import java.util.List;

//import com.capg.bank.entity.BankBean;
import com.capg.im.entity.RawMaterialBean;

public interface ITrackOrderService {
	
	//public RawMaterialBean trackOrder(String OrderId) ;
	//public boolean RawMaterialOrderIdExists(String Id);
	public RawMaterialBean insertRawMaterials(RawMaterialBean bean);
}