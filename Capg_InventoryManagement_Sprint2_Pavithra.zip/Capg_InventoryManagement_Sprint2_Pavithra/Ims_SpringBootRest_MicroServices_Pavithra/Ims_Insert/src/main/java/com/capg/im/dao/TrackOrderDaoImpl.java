package com.capg.im.dao;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.History;
//import com.capg.bank.entity.BankBean;
//import com.capg.bank.entity.History;
//import com.capg.bank.entity.BankBean;
import com.capg.im.entity.RawMaterialBean;
@Repository
@Transactional
public class TrackOrderDaoImpl implements ITrackOrderDao{
	@PersistenceContext
	EntityManager em;
	/** @author pavithra :
	 * This insertRawMaterials method will 
	 * insert details into the entity of rawmaterialbean **/
	@Override
	public RawMaterialBean insertRawMaterials(RawMaterialBean bean) {
			 em.persist(bean);
		 	 return bean;
		 }}