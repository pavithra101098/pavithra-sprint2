package com.capg.im;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImsInsertApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImsInsertApplication.class, args);
		System.out.println("Code Running");
	}

}
